# Screenshots

Replace this file with your own terminal screenshots, named exactly as below:

- `01-add-asset.png` — adding assets through menu option 1
- `02-display-assets.png` — full inventory report from menu option 2
- `03-search-asset.png` — a successful search and a "no match" search
- `04-update-asset.png` — updating a field of an existing asset
- `05-delete-asset.png` — deleting an asset with confirmation
- `06-security-summary.png` — the security summary report
- `07-input-validation.png` — rejected invalid IP, duplicate ID, invalid risk level
